package com.example.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.roundToInt

data class DragTarget(val id: String?, val pkg: String?, val bounds: Rect, val drawer: Boolean)
data class DragSession(val id: String?, val pkg: String?, val fromDrawer: Boolean)

/** Hareket dinleyicisi kökte kalır; çekmece kapanınca parmak takibi kesilmez. */
class LauncherDragState {
    val targets = mutableMapOf<String, DragTarget>()
    var session by mutableStateOf<DragSession?>(null)
    var position by mutableStateOf(Offset.Zero)
    var homeBounds by mutableStateOf(Rect.Zero)
    var removeBounds by mutableStateOf(Rect.Zero)

    fun cell(): Pair<Int, Int>? {
        val b = homeBounds
        if (b.width <= 0 || b.height <= 0 || !b.contains(position)) return null
        return floor((position.x - b.left) / (b.width / COLS)).toInt() to
            floor((position.y - b.top) / (b.height / ROWS)).toInt()
    }
}

@Composable
fun Modifier.dragTarget(state: LauncherDragState, key: String, id: String? = null, pkg: String? = null,
                        drawer: Boolean = false): Modifier {
    DisposableEffect(state, key) { onDispose { state.targets.remove(key) } }
    return onGloballyPositioned { state.targets[key] = DragTarget(id, pkg, it.boundsInRoot(), drawer) }
}

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    val drag = remember { LauncherDragState() }
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    fun cancelDrag() {
        if (drag.session?.fromDrawer == true) vm.drawerOpen = true
        drag.session = null
    }
    BackHandler(enabled = drag.session != null || vm.drawerOpen || vm.openFolder != null || vm.pickerFolder != null) {
        when {
            drag.session != null -> cancelDrag()
            vm.pickerFolder != null -> vm.pickerFolder = null
            vm.openFolder != null -> vm.openFolder = null
            else -> vm.drawerOpen = false
        }
    }
    Box(Modifier.fillMaxSize().pointerInput(vm, drag) {
        detectDragGesturesAfterLongPress(
            onDragStart = { point ->
                if (vm.openFolder == null && vm.pickerFolder == null) {
                    val target = drag.targets.values.lastOrNull {
                        it.drawer == vm.drawerOpen && it.bounds.contains(point)
                    }
                    if (target != null) {
                        drag.position = point
                        drag.session = DragSession(target.id, target.pkg, target.drawer)
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (target.drawer) vm.drawerOpen = false
                    }
                }
            },
            onDrag = { change, _ ->
                if (drag.session != null) {
                    change.consume()
                    drag.position = change.position
                }
            },
            onDragEnd = {
                drag.session?.let { source ->
                    if (!source.fromDrawer && drag.removeBounds.contains(drag.position)) {
                        source.id?.let(vm::remove)
                    } else {
                        val cell = drag.cell()
                        if (cell == null) {
                            if (source.fromDrawer) vm.drawerOpen = true
                        } else if (!vm.drop(source.id, source.pkg, cell.first, cell.second)) {
                            toast(ctx, "Bu alana bırakılamıyor; boş bir hücre seç")
                            if (source.fromDrawer) vm.drawerOpen = true
                        }
                    }
                }
                drag.session = null
            },
            onDragCancel = { cancelDrag() }
        )
    }) {
        HomeScreen(vm, drag)
        // Kaynak simgeyle birlikte çekmeceyi kaldırmak hareketi iptal etmez: dinleyici bu Box'tadır.
        if (vm.drawerOpen) DrawerScreen(vm, drag)
        vm.openFolder?.let { FolderPopup(vm, it) }
        vm.pickerFolder?.let { PickerDialog(vm, it) }
        drag.session?.let { source ->
            val removing = !source.fromDrawer && drag.removeBounds.contains(drag.position)
            Box(Modifier.align(Alignment.TopCenter).systemBarsPadding().padding(top = 8.dp)
                .onGloballyPositioned { drag.removeBounds = it.boundsInRoot() }
                .background(if (removing) Color(0xFFB3261E) else Color(0xE6353542), RoundedCornerShape(24.dp))
                .padding(horizontal = 22.dp, vertical = 14.dp)) {
                Text(if (source.fromDrawer) "Ana ekrana bırak" else "Kaldırmak için buraya bırak", color = Color.White)
            }
            val half = with(density) { 42.dp.toPx() }
            Column(Modifier.offset { IntOffset((drag.position.x - half).roundToInt(), (drag.position.y - half).roundToInt()) }
                .size(84.dp).alpha(0.92f)
                .background(Color(0x99353542), RoundedCornerShape(20.dp))
                .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                val item = vm.items.firstOrNull { it.id == source.id }
                val pkg = source.pkg ?: (item as? HomeItem.App)?.pkg
                if (pkg != null) {
                    Image(vm.icon(pkg), vm.label(pkg), Modifier.size(52.dp))
                } else {
                    Text("▦", color = Color.White, fontSize = 32.sp)
                    Text((item as? HomeItem.Folder)?.name ?: "Klasör", color = Color.White, maxLines = 1, fontSize = 11.sp)
                }
            }
        }
    }
}
