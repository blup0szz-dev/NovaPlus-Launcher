package com.example.launcher

import android.content.Intent
import android.provider.AlarmClock
import android.text.format.DateFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.TextClock
import java.util.Locale

/** TextClock dakika, saat dilimi ve sistem saati değişimlerini kendisi takip eder. */
@Composable
fun ClockWidget() {
    val ctx = LocalContext.current
    val datePattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "MMMMEEEEd")
    Column(Modifier.fillMaxWidth().height(146.dp).clickable {
        try { ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        catch (_: Exception) { toast(ctx, "Saat uygulaması bulunamadı") }
    }.padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        AndroidView(factory = { context ->
            TextClock(context).apply {
                format12Hour = "h:mm a"
                format24Hour = "HH:mm"
                textSize = 56f
                setTextColor(android.graphics.Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.NORMAL)
                importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
            }
        }, modifier = Modifier.wrapContentSize())
        AndroidView(factory = { context ->
            TextClock(context).apply {
                textSize = 15f
                setTextColor(0xDDFFFFFF.toInt())
            }
        }, update = { it.format12Hour = datePattern; it.format24Hour = datePattern },
            modifier = Modifier.wrapContentSize())
    }
}
