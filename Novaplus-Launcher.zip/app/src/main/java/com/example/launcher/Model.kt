package com.example.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val COLS = 4
const val ROWS = 6

data class AppInfo(val label: String, val pkg: String)

sealed class HomeItem {
    abstract val id: String
    abstract val col: Int
    abstract val row: Int

    data class App(
        override val id: String, val pkg: String,
        override val col: Int = -1, override val row: Int = -1
    ) : HomeItem()

    data class Folder(
        override val id: String, val name: String, val apps: List<String>,
        val big: Boolean = false,
        override val col: Int = -1, override val row: Int = -1
    ) : HomeItem()
}

val HomeItem.span: Int
    get() = if (this is HomeItem.Folder && big) 2 else 1

fun HomeItem.at(col: Int, row: Int): HomeItem = when (this) {
    is HomeItem.App -> copy(col = col, row = row)
    is HomeItem.Folder -> copy(col = col, row = row)
}

fun newId(): String = UUID.randomUUID().toString()
data class Placed(val item: HomeItem, val col: Int, val row: Int, val w: Int, val h: Int)

/** Önce kayıtlı konumları korur, sonra eski/yeni öğeleri boş hücrelere yerleştirir. */
fun pack(items: List<HomeItem>, cols: Int, rows: Int): List<Placed> {
    val occupied = Array(rows) { BooleanArray(cols) }
    val positions = HashMap<String, Placed>()
    fun free(c: Int, r: Int, size: Int): Boolean =
        c >= 0 && r >= 0 && c + size <= cols && r + size <= rows &&
            (r until r + size).all { y -> (c until c + size).all { x -> !occupied[y][x] } }
    fun place(item: HomeItem, c: Int, r: Int) {
        for (y in r until r + item.span) for (x in c until c + item.span) occupied[y][x] = true
        positions[item.id] = Placed(item, c, r, item.span, item.span)
    }
    items.forEach { if (free(it.col, it.row, it.span)) place(it, it.col, it.row) }
    items.filter { it.id !in positions }.forEach { item ->
        val cell = (0 until rows).asSequence().flatMap { r -> (0 until cols).asSequence().map { c -> c to r } }
            .firstOrNull { (c, r) -> free(c, r, item.span) }
        if (cell != null) place(item, cell.first, cell.second)
    }
    return items.mapNotNull { positions[it.id] }
}

/** Başarısız bırakma null döndürür; kaynak liste asla değiştirilmez. */
fun dropOnHome(items: List<HomeItem>, sourceId: String?, pkg: String?, col: Int, row: Int): List<HomeItem>? {
    val source = if (sourceId != null) items.firstOrNull { it.id == sourceId } ?: return null
        else HomeItem.App(newId(), pkg ?: return null)
    if (col < 0 || row < 0 || col + source.span > COLS || row + source.span > ROWS) return null
    val placed = pack(items, COLS, ROWS)
    val target = placed.firstOrNull { col in it.col until it.col + it.w && row in it.row until it.row + it.h }
    if (target?.item?.id == source.id && col == target.col && row == target.row) return items
    if (source is HomeItem.App && target != null) {
        val replacement = when (val item = target.item) {
            is HomeItem.App -> HomeItem.Folder(item.id, "Klasör", listOf(item.pkg, source.pkg).distinct(),
                col = target.col, row = target.row)
            is HomeItem.Folder -> item.copy(apps = (item.apps + source.pkg).distinct())
        }
        return items.filterNot { it.id == source.id }.map { if (it.id == target.item.id) replacement else it }
    }
    val overlaps = placed.any { it.item.id != source.id &&
        col < it.col + it.w && col + source.span > it.col &&
        row < it.row + it.h && row + source.span > it.row }
    if (overlaps) return null
    return items.filterNot { it.id == source.id } + source.at(col, row)
}

object Store {
    private const val FILE = "home"
    private const val KEY = "items"

    fun load(ctx: Context): List<HomeItem> {
        val s = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val col = o.optInt("col", -1)
                val row = o.optInt("row", -1)
                if (o.getString("t") == "app") HomeItem.App(o.getString("id"), o.getString("pkg"), col, row)
                else {
                    val a = o.getJSONArray("apps")
                    HomeItem.Folder(o.getString("id"), o.getString("name"),
                        (0 until a.length()).map { a.getString(it) }, o.optBoolean("big", false), col, row)
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(ctx: Context, items: List<HomeItem>) {
        val arr = JSONArray()
        for (item in items) {
            val o = JSONObject().put("id", item.id).put("col", item.col).put("row", item.row)
            when (item) {
                is HomeItem.App -> o.put("t", "app").put("pkg", item.pkg)
                is HomeItem.Folder -> {
                    o.put("t", "folder").put("name", item.name).put("big", item.big)
                    val apps = JSONArray()
                    item.apps.forEach { apps.put(it) }
                    o.put("apps", apps)
                }
            }
            arr.put(o)
        }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
