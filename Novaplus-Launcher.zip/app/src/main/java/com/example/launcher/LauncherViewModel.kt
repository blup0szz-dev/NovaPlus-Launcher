package com.example.launcher

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx = application
    private val pm = application.packageManager
    private val icons = HashMap<String, ImageBitmap>()

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var items by mutableStateOf<List<HomeItem>>(Store.load(application))
        private set

    var drawerOpen by mutableStateOf(false)
    var openFolder by mutableStateOf<String?>(null)
    var pickerFolder by mutableStateOf<String?>(null)

    fun closeOverlays() {
        drawerOpen = false
        openFolder = null
        pickerFolder = null
    }

    fun icon(pkg: String): ImageBitmap = icons.getOrPut(pkg) {
        try {
            pm.getApplicationIcon(pkg).toBitmap(120, 120).asImageBitmap()
        } catch (e: Exception) {
            pm.defaultActivityIcon.toBitmap(120, 120).asImageBitmap()
        }
    }

    fun label(pkg: String): String = apps.firstOrNull { it.pkg == pkg }?.label ?: pkg

    fun folder(id: String): HomeItem.Folder? =
        items.filterIsInstance<HomeItem.Folder>().firstOrNull { it.id == id }

    fun reload() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        if (list.isEmpty()) return
        apps = list
        val valid = list.map { it.pkg }.toSet()
        commit(items.mapNotNull {
            when (it) {
                is HomeItem.App -> if (it.pkg in valid) it else null
                is HomeItem.Folder -> it.copy(apps = it.apps.filter { p -> p in valid })
            }
        })
    }

    private fun commit(list: List<HomeItem>) {
        val placed = pack(list, COLS, ROWS)
        // Kapasite kontrolü çağıran tarafta yapılır; görünmeyen öğe kaydetme.
        if (placed.size != list.size) return
        val normalized = placed.map { it.item.at(it.col, it.row) }
        items = normalized
        Store.save(ctx, normalized)
    }

    private fun fits(list: List<HomeItem>) = pack(list, COLS, ROWS).size == list.size

    /** false dönerse ana ekranda yer yok. */
    fun addApp(pkg: String): Boolean {
        val n: List<HomeItem> = items + HomeItem.App(newId(), pkg)
        if (!fits(n)) return false
        commit(n)
        return true
    }

    fun drop(sourceId: String?, pkg: String?, col: Int, row: Int): Boolean {
        val next = dropOnHome(items, sourceId, pkg, col, row) ?: return false
        if (!fits(next)) return false
        commit(next)
        return true
    }

    fun remove(id: String) = commit(items.filter { it.id != id })

    fun makeFolder(appId: String) = commit(items.map {
        if (it.id == appId && it is HomeItem.App) HomeItem.Folder(it.id, "Klasör", listOf(it.pkg), col = it.col, row = it.row) else it
    })

    private fun editFolder(id: String, f: (HomeItem.Folder) -> HomeItem.Folder) =
        commit(items.map { if (it.id == id && it is HomeItem.Folder) f(it) else it })

    fun rename(id: String, name: String) = editFolder(id) { it.copy(name = name.ifBlank { "Klasör" }) }
    fun setApps(id: String, pkgs: List<String>) = editFolder(id) { it.copy(apps = pkgs) }
    fun removeFromFolder(id: String, pkg: String) = editFolder(id) { it.copy(apps = it.apps - pkg) }

    /** false dönerse 2x2 için yer yok. */
    fun setBig(id: String, big: Boolean): Boolean {
        val n = items.map { if (it.id == id && it is HomeItem.Folder) it.copy(big = big) else it }
        if (!fits(n)) return false
        commit(n)
        return true
    }
}
