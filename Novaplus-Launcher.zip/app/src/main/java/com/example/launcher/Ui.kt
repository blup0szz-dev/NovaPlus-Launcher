@file:OptIn(ExperimentalFoundationApi::class)

package com.example.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

// ---------- yardımcılar ----------

fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

fun openAppInfo(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun uninstallApp(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

// ---------- ana ekran ----------

@Composable
fun HomeScreen(vm: LauncherViewModel, drag: LauncherDragState) {
    val ctx = LocalContext.current
    var menuId by remember { mutableStateOf<String?>(null) }
    var renameId by remember { mutableStateOf<String?>(null) }
    val placed = remember(vm.items) { pack(vm.items, COLS, ROWS) }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(8.dp)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -100f) vm.drawerOpen = true },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
    ) {
        ClockWidget()
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)
            .onGloballyPositioned { drag.homeBounds = it.boundsInRoot() }) {
            val cellW = maxWidth / COLS
            val cellH = maxHeight / ROWS
            val dropCell = if (drag.session != null) drag.cell() else null
            if (dropCell != null) {
                Box(Modifier.offset(cellW * dropCell.first, cellH * dropCell.second)
                    .size(cellW, cellH).padding(3.dp)
                    .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(18.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.55f), RoundedCornerShape(18.dp)))
            }

            if (vm.items.isEmpty()) {
                Text(
                    "Uygulamaları görmek için yukarı kaydır",
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            placed.forEach { p ->
                key(p.item.id) {
                    Box(
                        Modifier
                            .offset(cellW * p.col, cellH * p.row)
                            .size(cellW * p.w, cellH * p.h)
                            .dragTarget(drag, "home:${p.item.id}", id = p.item.id,
                                pkg = (p.item as? HomeItem.App)?.pkg)
                            .alpha(if (drag.session?.id == p.item.id) 0.25f else 1f)
                            .padding(4.dp)
                    ) {
                        val item = p.item
                        when (item) {
                            is HomeItem.App -> {
                                Column(
                                    Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { launchApp(ctx, item.pkg) },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Image(vm.icon(item.pkg), null, Modifier.size(52.dp))
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        vm.label(item.pkg), color = Color.White, fontSize = 11.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                                DropdownMenu(expanded = menuId == item.id, onDismissRequest = { menuId = null }) {
                                    DropdownMenuItem(text = { Text("Klasör oluştur") }, onClick = {
                                        vm.makeFolder(item.id); menuId = null
                                    })
                                    DropdownMenuItem(text = { Text("Uygulama bilgisi") }, onClick = {
                                        openAppInfo(ctx, item.pkg); menuId = null
                                    })
                                    DropdownMenuItem(text = { Text("Ana ekrandan kaldır") }, onClick = {
                                        vm.remove(item.id); menuId = null
                                    })
                                }
                            }

                            is HomeItem.Folder -> {
                                if (item.big) {
                                    BigFolder(vm, item, { vm.openFolder = item.id })
                                } else {
                                    SmallFolder(vm, item, { vm.openFolder = item.id })
                                }
                                DropdownMenu(expanded = menuId == item.id, onDismissRequest = { menuId = null }) {
                                    DropdownMenuItem(text = { Text("Aç") }, onClick = {
                                        vm.openFolder = item.id; menuId = null
                                    })
                                    DropdownMenuItem(text = { Text("Uygulama ekle / çıkar") }, onClick = {
                                        vm.pickerFolder = item.id; menuId = null
                                    })
                                    DropdownMenuItem(text = { Text("Yeniden adlandır") }, onClick = {
                                        renameId = item.id; menuId = null
                                    })
                                    DropdownMenuItem(
                                        text = { Text(if (item.big) "Boyut: 1x1 yap" else "Boyut: 2x2 yap") },
                                        onClick = {
                                            if (!vm.setBig(item.id, !item.big)) toast(ctx, "Ana ekranda yer yok")
                                            menuId = null
                                        })
                                    DropdownMenuItem(text = { Text("Klasörü kaldır") }, onClick = {
                                        vm.remove(item.id); menuId = null
                                    })
                                }
                            }
                        }
                        Text("⋮", color = Color.White.copy(alpha = 0.8f), fontSize = 18.sp,
                            modifier = Modifier.align(Alignment.TopEnd)
                                .clickable { menuId = item.id }.padding(horizontal = 10.dp, vertical = 2.dp))
                    }
                }
            }
        }
    }

    renameId?.let { id ->
        val f = vm.folder(id)
        if (f != null) {
            RenameDialog(f.name, onDone = { vm.rename(id, it); renameId = null }, onDismiss = { renameId = null })
        }
    }
}

// 1x1: içinde 2x2 küçük ikon önizlemesi olan klasör
@Composable
fun SmallFolder(vm: LauncherViewModel, f: HomeItem.Folder, onOpen: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.25f))
                .padding(5.dp)
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                for (r in 0..1) {
                    Row(
                        Modifier.fillMaxWidth().weight(1f),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in 0..1) {
                            val pkg = f.apps.getOrNull(r * 2 + c)
                            if (pkg != null) Image(vm.icon(pkg), null, Modifier.size(21.dp))
                            else Spacer(Modifier.size(21.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(f.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// 2x2: ikonlar doğrudan tıklanabilir (3x3'e kadar), başlığa dokununca klasör açılır
@Composable
fun BigFolder(vm: LauncherViewModel, f: HomeItem.Folder, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.25f))
            .clickable(onClick = onOpen)
            .padding(8.dp)
    ) {
        Text(
            f.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 6.dp, bottom = 4.dp)
        )
        for (r in 0..2) {
            Row(Modifier.fillMaxWidth().weight(1f)) {
                for (c in 0..2) {
                    val pkg = f.apps.getOrNull(r * 3 + c)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { if (pkg != null) launchApp(ctx, pkg) else onOpen() }
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (pkg != null) Image(vm.icon(pkg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                }
            }
        }
    }
}

@Composable
fun RenameDialog(initial: String, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Klasör adı") },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onDone(text) }) { Text("Tamam") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

// ---------- uygulama çekmecesi ----------

@Composable
fun DrawerScreen(vm: LauncherViewModel, drag: LauncherDragState) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    val list = remember(vm.apps, query) {
        if (query.isBlank()) vm.apps else vm.apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2101014))
            .systemBarsPadding()
            .padding(horizontal = 12.dp)
    ) {
        Text(
            "⌄", color = Color.White, fontSize = 28.sp,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clickable { vm.drawerOpen = false }
                .padding(8.dp)
        )
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Uygulama ara") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
            items(list, key = { it.pkg }) { app ->
                Box(Modifier.dragTarget(drag, "drawer:${app.pkg}", pkg = app.pkg, drawer = true)) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { launchApp(ctx, app.pkg); vm.drawerOpen = false }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(vm.icon(app.pkg), null, Modifier.size(52.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(
                            app.label, color = Color.White, fontSize = 11.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text("⋮", color = Color.White.copy(alpha = 0.8f), fontSize = 18.sp,
                        modifier = Modifier.align(Alignment.TopEnd)
                            .clickable { menuPkg = app.pkg }.padding(horizontal = 10.dp, vertical = 2.dp))
                    DropdownMenu(expanded = menuPkg == app.pkg, onDismissRequest = { menuPkg = null }) {
                        DropdownMenuItem(text = { Text("Ana ekrana ekle") }, onClick = {
                            if (vm.addApp(app.pkg)) vm.drawerOpen = false else toast(ctx, "Ana ekran dolu")
                            menuPkg = null
                        })
                        DropdownMenuItem(text = { Text("Uygulama bilgisi") }, onClick = {
                            openAppInfo(ctx, app.pkg); menuPkg = null
                        })
                        DropdownMenuItem(text = { Text("Kaldır") }, onClick = {
                            uninstallApp(ctx, app.pkg); menuPkg = null
                        })
                    }
                }
            }
        }
    }
}

// ---------- klasör penceresi ----------

@Composable
fun FolderPopup(vm: LauncherViewModel, id: String) {
    val ctx = LocalContext.current
    val folder = vm.folder(id)
    if (folder == null) {
        LaunchedEffect(Unit) { vm.openFolder = null }
        return
    }
    var menuPkg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { vm.openFolder = null }) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xF0252528)) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    folder.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(12.dp))
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    if (folder.apps.isEmpty()) {
                        Text("Klasör boş", color = Color.White.copy(alpha = 0.6f))
                    }
                    folder.apps.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { pkg ->
                                Box(Modifier.weight(1f)) {
                                    Column(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .combinedClickable(
                                                onClick = { launchApp(ctx, pkg); vm.openFolder = null },
                                                onLongClick = { menuPkg = pkg }
                                            )
                                            .padding(vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Image(vm.icon(pkg), null, Modifier.size(44.dp))
                                        Text(
                                            vm.label(pkg), color = Color.White, fontSize = 10.sp,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    DropdownMenu(expanded = menuPkg == pkg, onDismissRequest = { menuPkg = null }) {
                                        DropdownMenuItem(text = { Text("Klasörden çıkar") }, onClick = {
                                            vm.removeFromFolder(id, pkg); menuPkg = null
                                        })
                                    }
                                }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
                TextButton(
                    onClick = { vm.pickerFolder = id },
                    modifier = Modifier.align(Alignment.End)
                ) { Text("+ Uygulama ekle") }
            }
        }
    }
}

@Composable
fun PickerDialog(vm: LauncherViewModel, id: String) {
    val folder = vm.folder(id) ?: return
    val selected = remember { mutableStateListOf<String>().apply { addAll(folder.apps) } }

    Dialog(onDismissRequest = { vm.pickerFolder = null }) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xF0252528)) {
            Column(Modifier.padding(16.dp)) {
                Text("Uygulama seç", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 420.dp)) {
                    items(vm.apps, key = { it.pkg }) { app ->
                        val on = app.pkg in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { if (on) selected.remove(app.pkg) else selected.add(app.pkg) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(vm.icon(app.pkg), null, Modifier.size(36.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                            Checkbox(checked = on, onCheckedChange = null)
                        }
                    }
                }
                TextButton(
                    onClick = { vm.setApps(id, selected.toList()); vm.pickerFolder = null },
                    modifier = Modifier.align(Alignment.End)
                ) { Text("Bitti") }
            }
        }
    }
}
