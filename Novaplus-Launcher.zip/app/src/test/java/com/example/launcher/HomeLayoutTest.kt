package com.example.launcher

import org.junit.Assert.*
import org.junit.Test

class HomeLayoutTest {
    private fun app(id: String, col: Int, row: Int) = HomeItem.App(id, "pkg.$id", col, row)

    @Test fun legacyItemsGetFreeCellsWithoutDisplacingSavedItems() {
        val saved = app("saved", 0, 0)
        val result = pack(listOf(HomeItem.App("old", "old.pkg"), saved), COLS, ROWS)
        assertEquals(0, result.first { it.item.id == "saved" }.col)
        assertEquals(1, result.first { it.item.id == "old" }.col)
    }

    @Test fun movingToEmptyCellPreservesOtherPositions() {
        val result = dropOnHome(listOf(app("a", 0, 0), app("b", 1, 0)), "a", null, 3, 5)!!
        assertEquals(3, result.first { it.id == "a" }.col)
        assertEquals(5, result.first { it.id == "a" }.row)
        assertEquals(1, result.first { it.id == "b" }.col)
        assertEquals(0, result.first { it.id == "b" }.row)
    }

    @Test fun appOnAppCreatesFolderAtTargetAndRemovesSource() {
        val result = dropOnHome(listOf(app("a", 0, 0), app("b", 2, 3)), "a", null, 2, 3)!!
        assertEquals(1, result.size)
        val folder = result.single() as HomeItem.Folder
        assertEquals(listOf("pkg.b", "pkg.a"), folder.apps)
        assertEquals(2, folder.col)
        assertEquals(3, folder.row)
    }

    @Test fun drawerDropAddsAppAtExactCell() {
        val result = dropOnHome(emptyList(), null, "new.pkg", 3, 4)!!
        assertEquals("new.pkg", (result.single() as HomeItem.App).pkg)
        assertEquals(3, result.single().col)
        assertEquals(4, result.single().row)
    }

    @Test fun drawerDropOnAppCreatesFolderWithoutRemovingTarget() {
        val result = dropOnHome(listOf(app("a", 1, 1)), null, "drawer.pkg", 1, 1)!!
        assertEquals(listOf("pkg.a", "drawer.pkg"), (result.single() as HomeItem.Folder).apps)
    }

    @Test fun appIntoFolderDeduplicatesAndKeepsSizeAndName() {
        val folder = HomeItem.Folder("f", "Araçlar", listOf("pkg.a"), true, 2, 2)
        val result = dropOnHome(listOf(app("a", 0, 0), folder), "a", null, 3, 3)!!
        assertEquals(folder, result.single())
    }

    @Test fun fullHomeCanStillMergeDrawerAppIntoFolder() {
        val full = (0 until COLS * ROWS).map { app("$it", it % COLS, it / COLS) }
        val result = dropOnHome(full, null, "extra.pkg", 0, 0)!!
        assertEquals(COLS * ROWS, result.size)
        assertEquals(2, (result.first() as HomeItem.Folder).apps.size)
        assertEquals(result.size, pack(result, COLS, ROWS).size)
    }

    @Test fun invalidDropsDoNotChangeSource() {
        val original = listOf(app("a", 0, 0))
        assertNull(dropOnHome(original, "a", null, -1, 0))
        assertNull(dropOnHome(original, "a", null, COLS, 0))
        assertNull(dropOnHome(original, "a", null, 0, ROWS))
        assertNull(dropOnHome(original, "missing", null, 0, 1))
        assertNull(dropOnHome(original, null, null, 0, 1))
        assertEquals(listOf(app("a", 0, 0)), original)
    }

    @Test fun droppingOnSelfIsNoOp() {
        val original = listOf(app("a", 0, 0))
        assertEquals(original, dropOnHome(original, "a", null, 0, 0))
    }

    @Test fun bigFolderCannotCoverAnotherItemOrOverflow() {
        val original = listOf(HomeItem.Folder("f", "Klasör", emptyList(), true, 0, 0), app("a", 2, 2))
        assertNull(dropOnHome(original, "f", null, 1, 1))
        assertNull(dropOnHome(original, "f", null, 3, 5))
        assertNull(dropOnHome(original, "f", null, 2, 2))
        val moved = dropOnHome(original, "f", null, 2, 4)!!
        assertEquals(4, moved.first { it.id == "f" }.row)
        assertEquals(2, pack(moved, COLS, ROWS).size)
    }

    @Test fun bigFolderCanMoveOneCellAcrossItsOldFootprint() {
        val folder = HomeItem.Folder("f", "Klasör", emptyList(), true, 0, 0)
        val result = dropOnHome(listOf(folder), "f", null, 1, 1)!!
        assertEquals(1, result.single().col)
        assertEquals(1, result.single().row)
    }

    @Test fun packingNeverOverlapsOrExitsGrid() {
        repeat(100) { seed ->
            val random = kotlin.random.Random(seed)
            val items = (0..25).map {
                if (random.nextBoolean()) app("$it", random.nextInt(-1, 5), random.nextInt(-1, 7))
                else HomeItem.Folder("$it", "f", emptyList(), random.nextBoolean(),
                    random.nextInt(-1, 5), random.nextInt(-1, 7))
            }
            val occupied = mutableSetOf<Pair<Int, Int>>()
            for (p in pack(items, COLS, ROWS)) {
                assertTrue(p.col >= 0 && p.row >= 0 && p.col + p.w <= COLS && p.row + p.h <= ROWS)
                for (r in p.row until p.row + p.h) for (c in p.col until p.col + p.w) {
                    assertTrue("Üst üste binen hücre: $seed/$c/$r", occupied.add(c to r))
                }
            }
        }
    }
}
