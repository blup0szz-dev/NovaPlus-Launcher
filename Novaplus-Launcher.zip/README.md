# MyLauncher 0.2

Jetpack Compose ile geliştirilmiş, One UI esintili basit Android launcher.

## Eklenenler

- Ana ekranın üstünde saat ve tarih. Sistem dili, saat dilimi ve 12/24 saat tercihi kullanılır. Saate dokunmak cihazın saat/alarm uygulamasını açar. Bu launcher içi sabit bir bileşendir; üçüncü taraf Android widget barındırma desteği değildir.
- Ana ekrandaki uygulama veya klasöre basılı tutup sürükleyerek konum değiştirme.
- Bir uygulamayı diğer uygulamanın üzerine bırakınca klasör oluşturma; mevcut klasöre bırakınca içine ekleme.
- Çekmecedeki uygulamaya basılı tutunca çekmecenin kapanması ve parmak kaldırılmadan ana ekrana sürüklenebilmesi.
- Bırakılacak hücrenin vurgulanması, sürüklenen simgenin önizlemesi ve titreşim geri bildirimi.
- Hücre konumlarının kaydedilmesi. Önceki sürümün uygulama/klasör kayıtları okunmaya devam eder.
- Ana ekrandan kaldırmak için sürüklerken üstteki kaldırma alanına bırakma. Bu işlem uygulamayı cihazdan silmez.

## Kullanım

1. Ana ekranda yukarı kaydırarak uygulama çekmecesini aç.
2. Bir simgeye basılı tut ve parmağını kaldırmadan boş bir hücreye sürükle.
3. Klasör oluşturmak için uygulamayı başka bir uygulamanın hücresine bırak.
4. Klasörün içine eklemek için uygulamayı klasörün üzerine bırak.
5. Ek seçeneklere simgenin sağ üstündeki **⋮** düğmesinden ulaş. Basılı tutma artık sürükleme içindir.
6. Bir hareketi iptal etmek için geri tuşunu kullan veya simgeyi ızgara dışına bırak. Başarısız bırakmalarda mevcut düzen korunur.

Saat üstte ayrı bir alan kullanır. Uygulama ızgarası yine 4 sütun × 6 satırdır. 2×2 klasörler boş alana taşınabilir; klasörün başka bir klasöre sürüklenmesi desteklenmez. Çekmeceden sürükleme kısayol ekler, uygulamayı çekmeceden kaldırmaz. Boş yer yoksa bir uygulama/klasör üzerine bırakarak gruplayabilirsin.

## GitHub üzerinden APK derleme

Arşivin içeriğini mevcut deponun köküne, `app/` ve `.github/` dahil, mevcut dosyaların üzerine kopyala. GitHub Actions iş akışı `main` veya `master` dalına push ile ya da **Actions → Build APK → Run workflow** üzerinden çalışır.

İş akışı birim testlerini çalıştırır, ardından debug APK üretir. Başarılı işin **Artifacts → launcher-debug-apk** bölümünden indir.

Yerelde JDK 17, Android SDK 34 ve Gradle 8.9 ile:

```sh
gradle testDebugUnitTest assembleDebug --no-daemon
```

Birim testleri konum koruma, eski kayıtların yerleşimi, klasör birleştirme, dolu ekran, geçersiz bırakmalar ve çakışma kontrolünü kapsar. Dokunma davranışı, farklı ekranlar ve OEM saat uygulamaları için gerçek cihaz testi de yapılmalıdır.

**İmza notu:** Başka bir bilgisayarda derlenen debug APK, mevcut APK ile farklı imzaya sahip olabilir. Android bu durumda üzerine kurmaya izin vermez. Verileri korumak için mevcut GitHub derleme/imza yöntemini kullan. Uygulamayı kaldırmak kayıtlı ana ekran düzenini siler.
