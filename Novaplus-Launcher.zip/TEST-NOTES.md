# Doğrulama

Bu teslimde JDK 17, Gradle 8.9 ve Android SDK 34 kullanıldı.

- `testDebugUnitTest`: 12 test başarılı, 0 hata, 0 atlanan test.
- `assembleDebug`: başarılı, kurulabilir debug APK üretildi.
- `lintDebug`: 0 hata, 7 uyarı. Uyarılar eski bağımlılık sürümleri, mevcut dikey ekran kilidi ve yedekleme ayarıyla ilgilidir. Bu çalışma kapsamında bağımlılık/SDK yükseltmesi yapılmadı.
- `apksigner verify`: başarılı.

Gerçek telefon veya emülatör üzerinde etkileşim testi yapılmadı. Özellikle aşağıdakiler cihazda denenmeli:

1. Ana ekranda simgeyi boş hücreye taşı, launcher'ı yeniden aç; konumu korunmalı.
2. Uygulamayı başka bir uygulamanın üzerine bırak; iki uygulamalı klasör oluşmalı.
3. Çekmecede kaydırmanın normal çalıştığını kontrol et. Bir uygulamaya basılı tut; çekmece kapanmalı ve parmağını kaldırmadan ana ekrana bırakabilmelisin.
4. Uygulamayı mevcut 1×1 veya 2×2 klasörün üzerine bırak; klasöre eklenmeli.
5. 2×2 klasörü boş bölgeye taşı; başka simgeleri kapatmamalı.
6. Sürüklerken geri tuşuyla iptal et, ızgara dışına bırak ve kaldırma alanını dene.
7. Sistemde saat biçimini/saat dilimini değiştir; saat güncellenmeli. Saate dokununca cihazın saat/alarm uygulaması açılmalı.

Birlikte verilen APK yeni bir debug anahtarıyla imzalanmıştır. Mevcut kurulumla imza çakışması olabilir; veri kaybını önlemek için güncellemede kendi GitHub derleme/imza yöntemini kullan.
