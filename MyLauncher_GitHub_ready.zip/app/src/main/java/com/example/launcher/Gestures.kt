package com.example.launcher

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange

/**
 * Dokun = onTap
 * Basılı tut + kaydır = sürükle (onDragStart → onDrag... → onDragEnd)
 * Basılı tut + bırak (kıpırdamadan) = onMenu
 * Basılı tutma anında onLongPress (titreşim için) çağrılır.
 */
@Composable
fun Modifier.pressGestures(
    onTap: (Offset) -> Unit,
    onLongPress: () -> Unit,
    onDragStart: (Offset) -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
    onMenu: () -> Unit
): Modifier {
    val tap by rememberUpdatedState(onTap)
    val longPress by rememberUpdatedState(onLongPress)
    val dragStart by rememberUpdatedState(onDragStart)
    val dragMove by rememberUpdatedState(onDrag)
    val dragEnd by rememberUpdatedState(onDragEnd)
    val dragCancel by rememberUpdatedState(onDragCancel)
    val menu by rememberUpdatedState(onMenu)

    return pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val slop = viewConfiguration.touchSlop

            // 1 = dokunuş, 3 = iptal (kaydırma vs.), null = uzun basma süresi doldu
            val first = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                var r = 0
                while (r == 0) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull { it.id == down.id }
                    r = when {
                        ch == null || ch.isConsumed -> 3
                        !ch.pressed -> 1
                        (ch.position - down.position).getDistance() > slop -> 3
                        else -> 0
                    }
                }
                r
            }

            if (first == 1) {
                tap(down.position)
                return@awaitEachGesture
            }
            if (first != null) return@awaitEachGesture

            // uzun basıldı
            longPress()
            var total = Offset.Zero
            var started = false
            val completed = drag(down.id) { ch ->
                val d = ch.positionChange()
                total += d
                if (!started) {
                    if (total.getDistance() > slop) {
                        started = true
                        dragStart(ch.position)
                    }
                } else {
                    dragMove(d)
                }
                ch.consume()
            }
            if (!started) {
                if (completed) menu()
            } else {
                if (completed) dragEnd() else dragCancel()
            }
        }
    }
}
