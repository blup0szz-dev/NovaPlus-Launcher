@file:OptIn(ExperimentalFoundationApi::class)

package com.example.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

// ---------- yardımcılar ----------

fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

fun openAppInfo(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun uninstallApp(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun openClockApp(ctx: Context) {
    try {
        ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
    }
}

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

/** Bir öğenin ekrandaki konum/boyut bilgisi (sürükleme başlangıcı için). */
class Geo {
    var size = IntSize.Zero
    var pos = Offset.Zero
}

private val BIG_HEADER = 22.dp

// ---------- kök ----------

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    BackHandler(enabled = vm.drawerOpen || vm.openFolder != null || vm.pickerFolder != null) {
        when {
            vm.pickerFolder != null -> vm.pickerFolder = null
            vm.openFolder != null -> vm.openFolder = null
            else -> vm.drawerOpen = false
        }
    }
    Box(Modifier.fillMaxSize()) {
        HomeScreen(vm)
        AnimatedVisibility(
            visible = vm.drawerOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) { DrawerScreen(vm) }
        vm.openFolder?.let { FolderPopup(vm, it) }
        vm.pickerFolder?.let { PickerDialog(vm, it) }
        DragGhost(vm)
    }
}

// ---------- ana ekran ----------

@Composable
fun HomeScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var menuId by remember { mutableStateOf<String?>(null) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var bgMenu by remember { mutableStateOf<Offset?>(null) }

    val draggingId by remember { derivedStateOf { vm.drag?.itemId } }
    val hoverId by remember {
        derivedStateOf { (vm.drag?.let { vm.plan(it) } as? DropPlan.Merge)?.target?.id }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(8.dp)
            .onGloballyPositioned { vm.gridOrigin = it.positionInRoot() }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -100f) vm.drawerOpen = true },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
    ) {
        val cellW = maxWidth / COLS
        val cellH = maxHeight / ROWS
        SideEffect {
            vm.cellW = with(density) { cellW.toPx() }
            vm.cellH = with(density) { cellH.toPx() }
        }

        // boş alana uzun basınca: saat widget'ı ekle
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { pos ->
                        if (vm.items.none { it is HomeItem.Clock }) bgMenu = pos
                    })
                }
        )

        if (vm.items.isEmpty()) {
            Text(
                "Uygulamaları görmek için yukarı kaydır",
                color = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.align(Alignment.Center)
            )
        }

        DropPreview(vm, cellW, cellH)

        vm.items.forEach { item ->
            key(item.id) {
                val geo = remember { Geo() }
                val targetX = cellW * item.col
                val targetY = cellH * item.row
                val targetWidth = cellW * item.w
                val targetHeight = cellH * item.h
                val animatedX by animateDpAsState(targetX, animationSpec = tween(320), label = "tileX")
                val animatedY by animateDpAsState(targetY, animationSpec = tween(320), label = "tileY")
                val animatedWidth by animateDpAsState(targetWidth, animationSpec = tween(320), label = "tileWidth")
                val animatedHeight by animateDpAsState(targetHeight, animationSpec = tween(320), label = "tileHeight")
                val tileAlpha by animateFloatAsState(
                    if (draggingId == item.id) 0f else 1f,
                    animationSpec = tween(140), label = "tileAlpha"
                )
                val tileSurface by animateColorAsState(
                    if (hoverId == item.id) Color.White.copy(alpha = 0.24f) else Color.Transparent,
                    animationSpec = tween(180), label = "tileSurface"
                )
                Box(
                    Modifier
                        .offset(animatedX, animatedY)
                        .size(animatedWidth, animatedHeight)
                        .padding(4.dp)
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = tileAlpha }
                            .clip(RoundedCornerShape(20.dp))
                            .background(tileSurface)
                            .onGloballyPositioned {
                                geo.size = it.size
                                geo.pos = it.positionInRoot()
                            }
                            .pressGestures(
                                onTap = { pos ->
                                    when (item) {
                                        is HomeItem.App -> launchApp(ctx, item.pkg)
                                        is HomeItem.Clock -> openClockApp(ctx)
                                        is HomeItem.Folder -> {
                                            if (item.big) {
                                                val pad = with(density) { 8.dp.toPx() }
                                                val head = with(density) { BIG_HEADER.toPx() }
                                                val iw = geo.size.width - 2 * pad
                                                val ih = geo.size.height - 2 * pad - head
                                                val x = pos.x - pad
                                                val y = pos.y - pad - head
                                                if (x >= 0f && y >= 0f && x < iw && y < ih) {
                                                    val idx = (y / ih * 3).toInt() * 3 + (x / iw * 3).toInt()
                                                    val pkg = item.apps.getOrNull(idx)
                                                    if (pkg != null) launchApp(ctx, pkg) else vm.openFolder = item.id
                                                } else {
                                                    vm.openFolder = item.id
                                                }
                                            } else {
                                                vm.openFolder = item.id
                                            }
                                        }
                                    }
                                },
                                onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                                onDragStart = { grab ->
                                    menuId = null
                                    vm.drag = Drag(
                                        item.id, null, false, item.w, item.h,
                                        geo.pos + grab, grab, geo.size
                                    )
                                },
                                onDrag = { vm.moveDrag(it) },
                                onDragEnd = { vm.endDrag()?.let { m -> toast(ctx, m) } },
                                onDragCancel = { vm.drag = null },
                                onMenu = { menuId = item.id }
                            )
                    ) {
                        HomeItemContent(vm, item)
                    }

                    when (item) {
                        is HomeItem.App -> DropdownMenu(expanded = menuId == item.id, onDismissRequest = { menuId = null }) {
                            DropdownMenuItem(text = { Text("Klasör oluştur") }, onClick = {
                                vm.makeFolder(item.id); menuId = null
                            })
                            DropdownMenuItem(text = { Text("Uygulama bilgisi") }, onClick = {
                                openAppInfo(ctx, item.pkg); menuId = null
                            })
                            DropdownMenuItem(text = { Text("Ana ekrandan kaldır") }, onClick = {
                                vm.remove(item.id); menuId = null
                            })
                        }

                        is HomeItem.Folder -> DropdownMenu(expanded = menuId == item.id, onDismissRequest = { menuId = null }) {
                            DropdownMenuItem(text = { Text("Aç") }, onClick = {
                                vm.openFolder = item.id; menuId = null
                            })
                            DropdownMenuItem(text = { Text("Uygulama ekle / çıkar") }, onClick = {
                                vm.pickerFolder = item.id; menuId = null
                            })
                            DropdownMenuItem(text = { Text("Yeniden adlandır") }, onClick = {
                                renameId = item.id; menuId = null
                            })
                            DropdownMenuItem(
                                text = { Text(if (item.big) "Boyut: 1x1 yap" else "Boyut: 2x2 yap") },
                                onClick = {
                                    if (!vm.setBig(item.id, !item.big)) toast(ctx, "Ana ekranda yer yok")
                                    menuId = null
                                })
                            DropdownMenuItem(text = { Text("Klasörü kaldır") }, onClick = {
                                vm.remove(item.id); menuId = null
                            })
                        }

                        is HomeItem.Clock -> DropdownMenu(expanded = menuId == item.id, onDismissRequest = { menuId = null }) {
                            DropdownMenuItem(text = { Text("Saat widget'ını kaldır") }, onClick = {
                                vm.remove(item.id); menuId = null
                            })
                        }
                    }
                }
            }
        }

        bgMenu?.let { pos ->
            Box(Modifier.offset { IntOffset(pos.x.roundToInt(), pos.y.roundToInt()) }.size(1.dp)) {
                DropdownMenu(expanded = true, onDismissRequest = { bgMenu = null }) {
                    DropdownMenuItem(text = { Text("Saat widget'ı ekle") }, onClick = {
                        val ok = vm.addClock(
                            (pos.x / vm.cellW).toInt().coerceIn(0, COLS - 1),
                            (pos.y / vm.cellH).toInt().coerceIn(0, ROWS - 1)
                        )
                        if (!ok) toast(ctx, "Ana ekranda yer yok")
                        bgMenu = null
                    })
                }
            }
        }
    }

    renameId?.let { id ->
        val f = vm.folder(id)
        if (f != null) {
            RenameDialog(f.name, onDone = { vm.rename(id, it); renameId = null }, onDismiss = { renameId = null })
        }
    }
}

@Composable
fun HomeItemContent(vm: LauncherViewModel, item: HomeItem) {
    when (item) {
        is HomeItem.App -> AppTile(vm, item.pkg)
        is HomeItem.Folder -> if (item.big) BigFolder(vm, item) else SmallFolder(vm, item)
        is HomeItem.Clock -> ClockWidget()
    }
}

@Composable
fun AppTile(vm: LauncherViewModel, pkg: String) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(vm.icon(pkg), null, Modifier.size(52.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            vm.label(pkg), color = Color.White, fontSize = 11.sp,
            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 1f), 3f)),
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

/** Bırakılacak boş hücreyi gösteren hafif gölge. */
@Composable
fun DropPreview(vm: LauncherViewModel, cellW: Dp, cellH: Dp) {
    val d = vm.drag ?: return
    val p = vm.plan(d) as? DropPlan.Place ?: return
    Box(
        Modifier
            .offset(cellW * p.col, cellH * p.row)
            .size(cellW * d.w, cellH * d.h)
            .padding(4.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.16f))
    )
}

/** Parmakla birlikte hareket eden öğe. */
@Composable
fun DragGhost(vm: LauncherViewModel) {
    val d = vm.drag ?: return
    val density = LocalDensity.current
    val item = d.itemId?.let { id -> vm.items.firstOrNull { it.id == id } }
    val pkg = d.pkg
    Box(
        Modifier
            .offset { IntOffset((d.finger.x - d.grab.x).roundToInt(), (d.finger.y - d.grab.y).roundToInt()) }
            .size(with(density) { d.size.width.toDp() }, with(density) { d.size.height.toDp() })
            .graphicsLayer { scaleX = 1.06f; scaleY = 1.06f; alpha = 0.96f; shadowElevation = 18f }
    ) {
        if (item != null) HomeItemContent(vm, item)
        else if (pkg != null) AppTile(vm, pkg)
    }
}

// ---------- saat widget'ı ----------

@Composable
fun ClockWidget() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val time = remember(now, is24) {
        now.format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm"))
    }
    val date = remember(now) {
        now.format(DateTimeFormatter.ofPattern("d MMMM EEEE", Locale.getDefault()))
    }
    val shadow = Shadow(Color.Black.copy(alpha = 0.48f), Offset(0f, 2f), 10f)

    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            time, color = Color.White, fontSize = 68.sp, fontWeight = FontWeight.Light,
            style = TextStyle(shadow = shadow), textAlign = TextAlign.Center
        )
        Text(
            date, color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp,
            style = TextStyle(shadow = shadow), textAlign = TextAlign.Center
        )
    }
}

// 1x1: içinde 2x2 küçük ikon önizlemesi olan klasör
@Composable
fun SmallFolder(vm: LauncherViewModel, f: HomeItem.Folder) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.22f))
                .padding(5.dp)
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                for (r in 0..1) {
                    Row(
                        Modifier.fillMaxWidth().weight(1f),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in 0..1) {
                            val pkg = f.apps.getOrNull(r * 2 + c)
                            if (pkg != null) Image(vm.icon(pkg), null, Modifier.size(21.dp))
                            else Spacer(Modifier.size(21.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(f.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// 2x2: 3x3 ikon gösterir. Dokunuşlar HomeScreen'de konuma göre çözülür.
@Composable
fun BigFolder(vm: LauncherViewModel, f: HomeItem.Folder) {
    Column(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.22f))
            .padding(8.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(BIG_HEADER), contentAlignment = Alignment.CenterStart) {
            Text(
                f.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 6.dp)
            )
        }
        for (r in 0..2) {
            Row(Modifier.fillMaxWidth().weight(1f)) {
                for (c in 0..2) {
                    val pkg = f.apps.getOrNull(r * 3 + c)
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (pkg != null) Image(vm.icon(pkg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                }
            }
        }
    }
}

@Composable
fun RenameDialog(initial: String, onDone: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Klasör adı") },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onDone(text) }) { Text("Tamam") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

// ---------- uygulama çekmecesi ----------

@Composable
fun DrawerScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var query by remember { mutableStateOf("") }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    val list = remember(vm.apps, query) {
        if (query.isBlank()) vm.apps else vm.apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    // Sürükleme başlayınca çekmece görünmez olur (ana ekran görünür), ama kompozisyonda kalır
    val hide by remember { derivedStateOf { vm.drag?.fromDrawer == true } }
    val drawerAlpha by animateFloatAsState(if (hide) 0f else 1f, label = "drawerAlpha")

    Column(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = drawerAlpha }
            .background(Color(0xE6101014))
            .systemBarsPadding()
            .padding(horizontal = 12.dp)
    ) {
        Text(
            "⌄", color = Color.White, fontSize = 28.sp,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clickable { vm.drawerOpen = false }
                .padding(8.dp)
        )
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Uygulama ara") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
            items(list, key = { it.pkg }) { app ->
                val geo = remember { Geo() }
                Box {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .onGloballyPositioned {
                                geo.size = it.size
                                geo.pos = it.positionInRoot()
                            }
                            .pressGestures(
                                onTap = { launchApp(ctx, app.pkg); vm.drawerOpen = false },
                                onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                                onDragStart = { grab ->
                                    menuPkg = null
                                    vm.drag = Drag(null, app.pkg, true, 1, 1, geo.pos + grab, grab, geo.size)
                                },
                                onDrag = { vm.moveDrag(it) },
                                onDragEnd = { vm.endDrag()?.let { m -> toast(ctx, m) } },
                                onDragCancel = { vm.drag = null },
                                onMenu = { menuPkg = app.pkg }
                            )
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(vm.icon(app.pkg), null, Modifier.size(52.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(
                            app.label, color = Color.White, fontSize = 11.sp,
                            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 1f), 3f)),
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    DropdownMenu(expanded = menuPkg == app.pkg, onDismissRequest = { menuPkg = null }) {
                        DropdownMenuItem(text = { Text("Ana ekrana ekle") }, onClick = {
                            if (vm.addApp(app.pkg)) vm.drawerOpen = false else toast(ctx, "Ana ekran dolu")
                            menuPkg = null
                        })
                        DropdownMenuItem(text = { Text("Uygulama bilgisi") }, onClick = {
                            openAppInfo(ctx, app.pkg); menuPkg = null
                        })
                        DropdownMenuItem(text = { Text("Kaldır") }, onClick = {
                            uninstallApp(ctx, app.pkg); menuPkg = null
                        })
                    }
                }
            }
        }
    }
}

// ---------- klasör penceresi ----------

@Composable
fun FolderPopup(vm: LauncherViewModel, id: String) {
    val ctx = LocalContext.current
    val folder = vm.folder(id)
    if (folder == null) {
        LaunchedEffect(Unit) { vm.openFolder = null }
        return
    }
    var menuPkg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { vm.openFolder = null }) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xF0252528)) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    folder.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(12.dp))
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    if (folder.apps.isEmpty()) {
                        Text("Klasör boş", color = Color.White.copy(alpha = 0.6f))
                    }
                    folder.apps.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { pkg ->
                                Box(Modifier.weight(1f)) {
                                    Column(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .pressGestures(
                                                onTap = { launchApp(ctx, pkg); vm.openFolder = null },
                                                onLongPress = {},
                                                onDragStart = {},
                                                onDrag = {},
                                                onDragEnd = {},
                                                onDragCancel = {},
                                                onMenu = { menuPkg = pkg }
                                            )
                                            .padding(vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Image(vm.icon(pkg), null, Modifier.size(44.dp))
                                        Text(
                                            vm.label(pkg), color = Color.White, fontSize = 10.sp,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    DropdownMenu(expanded = menuPkg == pkg, onDismissRequest = { menuPkg = null }) {
                                        DropdownMenuItem(text = { Text("Klasörden çıkar") }, onClick = {
                                            vm.removeFromFolder(id, pkg); menuPkg = null
                                        })
                                    }
                                }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
                TextButton(
                    onClick = { vm.pickerFolder = id },
                    modifier = Modifier.align(Alignment.End)
                ) { Text("+ Uygulama ekle") }
            }
        }
    }
}

@Composable
fun PickerDialog(vm: LauncherViewModel, id: String) {
    val folder = vm.folder(id) ?: return
    val selected = remember { mutableStateListOf<String>().apply { addAll(folder.apps) } }

    Dialog(onDismissRequest = { vm.pickerFolder = null }) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xF0252528)) {
            Column(Modifier.padding(16.dp)) {
                Text("Uygulama seç", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 420.dp)) {
                    items(vm.apps, key = { it.pkg }) { app ->
                        val on = app.pkg in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { if (on) selected.remove(app.pkg) else selected.add(app.pkg) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(vm.icon(app.pkg), null, Modifier.size(36.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                            Checkbox(checked = on, onCheckedChange = null)
                        }
                    }
                }
                TextButton(
                    onClick = { vm.setApps(id, selected.toList()); vm.pickerFolder = null },
                    modifier = Modifier.align(Alignment.End)
                ) { Text("Bitti") }
            }
        }
    }
}
