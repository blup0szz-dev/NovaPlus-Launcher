package com.example.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LauncherTheme { LauncherRoot(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.reload()
    }

    // Home tuşuna basılınca açık pencereleri kapat
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.closeOverlays()
    }
}
