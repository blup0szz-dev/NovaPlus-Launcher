package com.example.launcher

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import kotlin.math.floor

/** Sürüklenen öğe. Koordinatlar kök (ekran) koordinatlarıdır. */
data class Drag(
    val itemId: String?,     // ana ekrandan taşınan öğe (yoksa null)
    val pkg: String?,        // çekmeceden gelen uygulama (yoksa null)
    val fromDrawer: Boolean,
    val w: Int,
    val h: Int,
    val finger: Offset,      // parmağın şu anki konumu
    val grab: Offset,        // parmağın öğenin sol üstüne göre konumu
    val size: IntSize        // öğenin piksel boyutu
)

sealed class DropPlan {
    data class Merge(val target: HomeItem) : DropPlan() // klasör oluştur / klasöre ekle
    data class Place(val col: Int, val row: Int) : DropPlan()
    object None : DropPlan()
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx = application
    private val pm = application.packageManager
    private val icons = HashMap<String, ImageBitmap>()

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var items by mutableStateOf<List<HomeItem>>(Store.load(application))
        private set

    var drawerOpen by mutableStateOf(false)
    var openFolder by mutableStateOf<String?>(null)
    var pickerFolder by mutableStateOf<String?>(null)

    // sürükle-bırak
    var drag by mutableStateOf<Drag?>(null)
    var gridOrigin = Offset.Zero
    var cellW = 1f
    var cellH = 1f

    fun closeOverlays() {
        drawerOpen = false
        openFolder = null
        pickerFolder = null
        drag = null
    }

    fun icon(pkg: String): ImageBitmap = icons.getOrPut(pkg) {
        try {
            pm.getApplicationIcon(pkg).toBitmap(120, 120).asImageBitmap()
        } catch (e: Exception) {
            pm.defaultActivityIcon.toBitmap(120, 120).asImageBitmap()
        }
    }

    fun label(pkg: String): String = apps.firstOrNull { it.pkg == pkg }?.label ?: pkg

    fun folder(id: String): HomeItem.Folder? =
        items.filterIsInstance<HomeItem.Folder>().firstOrNull { it.id == id }

    fun reload() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        if (list.isEmpty()) return
        apps = list
        val valid = list.map { it.pkg }.toSet()
        commit(items.mapNotNull {
            when (it) {
                is HomeItem.App -> if (it.pkg in valid) it else null
                is HomeItem.Folder -> it.copy(apps = it.apps.filter { p -> p in valid })
                is HomeItem.Clock -> it
            }
        })
    }

    private fun commit(list: List<HomeItem>) {
        items = list
        Store.save(ctx, list)
    }

    /** false dönerse ana ekranda yer yok. */
    fun addApp(pkg: String): Boolean {
        val spot = findFree(items, 1, 1) ?: return false
        commit(items + HomeItem.App(newId(), pkg, spot.first, spot.second))
        return true
    }

    /** false dönerse 4x2 için yer yok. */
    fun addClock(nearC: Int, nearR: Int): Boolean {
        if (items.any { it is HomeItem.Clock }) return true
        val spot = findFree(items, 4, 2, nearC, nearR) ?: return false
        commit(items + HomeItem.Clock(newId(), spot.first, spot.second))
        return true
    }

    fun remove(id: String) = commit(items.filter { it.id != id })

    fun makeFolder(appId: String) = commit(items.map {
        if (it.id == appId && it is HomeItem.App) {
            HomeItem.Folder(it.id, "Klasör", listOf(it.pkg), false, it.col, it.row)
        } else it
    })

    private fun editFolder(id: String, f: (HomeItem.Folder) -> HomeItem.Folder) =
        commit(items.map { if (it.id == id && it is HomeItem.Folder) f(it) else it })

    fun rename(id: String, name: String) = editFolder(id) { it.copy(name = name.ifBlank { "Klasör" }) }
    fun setApps(id: String, pkgs: List<String>) = editFolder(id) { it.copy(apps = pkgs) }
    fun removeFromFolder(id: String, pkg: String) = editFolder(id) { it.copy(apps = it.apps - pkg) }

    /** false dönerse 2x2 için yer yok. */
    fun setBig(id: String, big: Boolean): Boolean {
        val cur = items.firstOrNull { it.id == id } as? HomeItem.Folder ?: return false
        val others = items.filter { it.id != id }
        val s = if (big) 2 else 1
        val spot = findFree(others, s, s, cur.col, cur.row) ?: return false
        commit(items.map {
            if (it.id == id) cur.copy(big = big, col = spot.first, row = spot.second) else it
        })
        return true
    }

    // ---------- sürükle-bırak ----------

    fun moveDrag(delta: Offset) {
        drag?.let { drag = it.copy(finger = it.finger + delta) }
    }

    /** Bırakılırsa ne olacağını hesaplar. */
    fun plan(d: Drag): DropPlan {
        val moving = d.itemId
        val others = items.filter { it.id != moving }
        val pkg = d.pkg ?: (items.firstOrNull { it.id == moving } as? HomeItem.App)?.pkg

        val fc = floor((d.finger.x - gridOrigin.x) / cellW).toInt()
        val fr = floor((d.finger.y - gridOrigin.y) / cellH).toInt()

        // Uygulama başka bir uygulamanın / klasörün üstüne geldiyse birleştir
        if (pkg != null && fc in 0 until COLS && fr in 0 until ROWS) {
            when (val t = others.firstOrNull { it.covers(fc, fr) }) {
                is HomeItem.App -> if (t.pkg != pkg) return DropPlan.Merge(t)
                is HomeItem.Folder -> return DropPlan.Merge(t)
                else -> {}
            }
        }

        // Aksi halde parmağın altındaki hücreye (veya en yakın boşluğa) yerleştir
        val gc = floor(d.grab.x / cellW).toInt().coerceIn(0, d.w - 1)
        val gr = floor(d.grab.y / cellH).toInt().coerceIn(0, d.h - 1)
        val c = (fc - gc).coerceIn(0, COLS - d.w)
        val r = (fr - gr).coerceIn(0, ROWS - d.h)
        val spot = findFree(others, d.w, d.h, c, r) ?: return DropPlan.None
        return DropPlan.Place(spot.first, spot.second)
    }

    /** Parmak kalktı. Hata mesajı döner (yer yoksa), yoksa null. */
    fun endDrag(): String? {
        val d = drag ?: return null
        drag = null
        val msg: String? = when (val p = plan(d)) {
            is DropPlan.Merge -> {
                merge(d, p.target)
                null
            }
            is DropPlan.Place -> {
                place(d, p.col, p.row)
                null
            }
            DropPlan.None -> "Ana ekranda yer yok"
        }
        if (d.fromDrawer) drawerOpen = false
        return msg
    }

    private fun merge(d: Drag, target: HomeItem) {
        val moving = d.itemId
        val pkg = d.pkg ?: (items.firstOrNull { it.id == moving } as? HomeItem.App)?.pkg ?: return
        val base = items.filter { it.id != moving }
        commit(base.map {
            when {
                it.id != target.id -> it
                it is HomeItem.App ->
                    HomeItem.Folder(it.id, "Klasör", listOf(it.pkg, pkg), false, it.col, it.row)
                it is HomeItem.Folder ->
                    if (pkg in it.apps) it else it.copy(apps = it.apps + pkg)
                else -> it
            }
        })
    }

    private fun place(d: Drag, c: Int, r: Int) {
        val id = d.itemId
        val pkg = d.pkg
        if (id != null) {
            commit(items.map { if (it.id == id) it.at(c, r) else it })
        } else if (pkg != null) {
            commit(items + HomeItem.App(newId(), pkg, c, r))
        }
    }
}
