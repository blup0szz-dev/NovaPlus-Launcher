package com.example.launcher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val COLS = 4
const val ROWS = 6

data class AppInfo(val label: String, val pkg: String)

/** col/row: ana ekran ızgarasındaki sol üst hücre (0 tabanlı). */
sealed class HomeItem {
    abstract val id: String
    abstract val col: Int
    abstract val row: Int

    data class App(
        override val id: String,
        val pkg: String,
        override val col: Int = -1,
        override val row: Int = -1
    ) : HomeItem()

    data class Folder(
        override val id: String,
        val name: String,
        val apps: List<String>,
        val big: Boolean = false, // false = 1x1, true = 2x2
        override val col: Int = -1,
        override val row: Int = -1
    ) : HomeItem()

    /** Saat widget'ı: 4x2 */
    data class Clock(
        override val id: String,
        override val col: Int = -1,
        override val row: Int = -1
    ) : HomeItem()
}

val HomeItem.w: Int
    get() = when (this) {
        is HomeItem.Folder -> if (big) 2 else 1
        is HomeItem.Clock -> 4
        is HomeItem.App -> 1
    }

val HomeItem.h: Int
    get() = when (this) {
        is HomeItem.Folder -> if (big) 2 else 1
        is HomeItem.Clock -> 2
        is HomeItem.App -> 1
    }

fun HomeItem.at(c: Int, r: Int): HomeItem = when (this) {
    is HomeItem.App -> copy(col = c, row = r)
    is HomeItem.Folder -> copy(col = c, row = r)
    is HomeItem.Clock -> copy(col = c, row = r)
}

fun HomeItem.covers(c: Int, r: Int): Boolean =
    c >= col && c < col + w && r >= row && r < row + h

fun newId(): String = UUID.randomUUID().toString()

/** w x h boyutunda, (nearC, nearR) hücresine en yakın boş yeri bulur. Yoksa null. */
fun findFree(items: List<HomeItem>, w: Int, h: Int, nearC: Int = 0, nearR: Int = 0): Pair<Int, Int>? {
    val occ = Array(ROWS) { BooleanArray(COLS) }
    for (i in items) {
        if (i.col < 0 || i.row < 0) continue
        for (r in i.row until minOf(ROWS, i.row + i.h))
            for (c in i.col until minOf(COLS, i.col + i.w)) occ[r][c] = true
    }
    var best: Pair<Int, Int>? = null
    var bestD = Int.MAX_VALUE
    for (r in 0..(ROWS - h)) {
        for (c in 0..(COLS - w)) {
            var free = true
            for (dr in 0 until h) for (dc in 0 until w) if (occ[r + dr][c + dc]) free = false
            if (!free) continue
            val d = (c - nearC) * (c - nearC) + (r - nearR) * (r - nearR)
            if (d < bestD) {
                bestD = d
                best = c to r
            }
        }
    }
    return best
}

object Store {
    private const val FILE = "home"
    private const val KEY = "items"
    private const val VERSION_KEY = "v"
    private const val VERSION = 2

    fun load(ctx: Context): List<HomeItem> {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val s = sp.getString(KEY, null)
            ?: return listOf(HomeItem.Clock(newId(), 0, 0)) // ilk açılış: saat widget'ı hazır gelir
        val raw = try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val c = o.optInt("c", -1)
                val r = o.optInt("r", -1)
                when (o.getString("t")) {
                    "app" -> HomeItem.App(o.getString("id"), o.getString("pkg"), c, r)
                    "clock" -> HomeItem.Clock(o.getString("id"), c, r)
                    else -> {
                        val a = o.getJSONArray("apps")
                        HomeItem.Folder(
                            o.getString("id"),
                            o.getString("name"),
                            (0 until a.length()).map { a.getString(it) },
                            o.optBoolean("big", false),
                            c, r
                        )
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
        return if (sp.getInt(VERSION_KEY, 1) < VERSION) migrate(raw) else raw
    }

    /** Eski kayıtlarda konum yok: öğeleri sırayla yerleştir. Önce saat widget'ı eklemeyi dener. */
    private fun migrate(raw: List<HomeItem>): List<HomeItem> {
        fun place(start: List<HomeItem>): List<HomeItem> {
            val out = start.toMutableList()
            for (item in raw) {
                val spot = findFree(out, item.w, item.h) ?: continue
                out.add(item.at(spot.first, spot.second))
            }
            return out
        }
        val withClock = place(listOf(HomeItem.Clock(newId(), 0, 0)))
        return if (withClock.size == raw.size + 1) withClock else place(emptyList())
    }

    fun save(ctx: Context, items: List<HomeItem>) {
        val arr = JSONArray()
        for (it in items) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("c", it.col)
            o.put("r", it.row)
            when (it) {
                is HomeItem.App -> {
                    o.put("t", "app")
                    o.put("pkg", it.pkg)
                }
                is HomeItem.Folder -> {
                    o.put("t", "folder")
                    o.put("name", it.name)
                    o.put("big", it.big)
                    val a = JSONArray()
                    it.apps.forEach { p -> a.put(p) }
                    o.put("apps", a)
                }
                is HomeItem.Clock -> o.put("t", "clock")
            }
            arr.put(o)
        }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString())
            .putInt(VERSION_KEY, VERSION)
            .apply()
    }
}
